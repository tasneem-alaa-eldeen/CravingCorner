<svg viewBox="0 0 100 100" xmlns="http://www.w3.org/2000/svg" {{ $attributes }}>
    <circle cx="50" cy="50" r="48" fill="var(--cc-ink)" />

    <!-- steam -->
    <path d="M38 26 Q35 20 40 14" stroke="var(--cc-mustard)" stroke-width="3.5" fill="none" stroke-linecap="round" />
    <path d="M50 26 Q47 20 52 14" stroke="var(--cc-mustard)" stroke-width="3.5" fill="none" stroke-linecap="round" />
    <path d="M62 26 Q59 20 64 14" stroke="var(--cc-mustard)" stroke-width="3.5" fill="none" stroke-linecap="round" />

    <!-- cup handle -->
    <path d="M69 44 Q82 44 82 54 Q82 64 69 64" stroke="var(--cc-paper)" stroke-width="5" fill="none" stroke-linecap="round" />

    <!-- cup body -->
    <path d="M26 34 H70 V58 Q70 76 48 76 Q26 76 26 58 Z" fill="var(--cc-paper)" />

    <!-- saucer -->
    <rect x="20" y="80" width="56" height="6" rx="3" fill="var(--cc-mustard)" />
</svg>
