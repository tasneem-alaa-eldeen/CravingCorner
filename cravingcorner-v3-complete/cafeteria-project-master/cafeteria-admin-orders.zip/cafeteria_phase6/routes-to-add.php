<?php
// Add to routes/web.php, inside your existing admin group
// (the one with 'auth','admin' middleware and 'admin.' name prefix):

use App\Http\Controllers\Admin\OrderController as AdminOrderController;

// Inside: Route::middleware(['auth', 'admin'])->prefix('admin')->name('admin.')->group(function () { ... })
Route::resource('orders', AdminOrderController::class)->only(['index', 'show', 'update']);
