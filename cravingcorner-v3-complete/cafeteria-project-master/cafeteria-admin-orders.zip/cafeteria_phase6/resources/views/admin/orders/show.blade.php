<x-app-layout>
    <x-slot name="header">
        <h2 class="font-semibold text-xl text-gray-800 leading-tight">Order #{{ $order->id }}</h2>
    </x-slot>

    <div class="py-8 max-w-2xl mx-auto sm:px-6 lg:px-8">
        @if (session('status'))
            <div class="mb-4 rounded-md bg-green-50 p-3 text-sm text-green-700">{{ session('status') }}</div>
        @endif

        <div class="bg-white shadow-sm rounded-lg p-6">
            <p class="text-sm text-gray-500 mb-1">Customer</p>
            <p class="mb-4">{{ $order->user->name ?? '—' }} ({{ $order->user->email ?? '' }})</p>

            <div class="divide-y mb-4">
                @foreach ($order->items as $line)
                    <div class="flex items-center justify-between py-2 text-sm">
                        <span>{{ $line->itemable->name ?? 'Item removed' }} &times; {{ $line->quantity }}</span>
                        <span>{{ number_format($line->subtotal, 2) }} EGP</span>
                    </div>
                @endforeach
            </div>

            <div class="flex justify-between font-semibold mb-6">
                <span>Total</span>
                <span>{{ number_format($order->total_price, 2) }} EGP</span>
            </div>

            <form action="{{ route('admin.orders.update', $order) }}" method="POST" class="space-y-4">
                @csrf
                @method('PUT')

                <div>
                    <label class="block text-sm font-medium text-gray-700 mb-1">Order status</label>
                    <select name="status" style="width:100%;" class="border-gray-300 rounded-md text-sm">
                        @foreach (['pending', 'preparing', 'ready', 'completed', 'cancelled'] as $status)
                            <option value="{{ $status }}" {{ $order->status === $status ? 'selected' : '' }}>{{ ucfirst($status) }}</option>
                        @endforeach
                    </select>
                </div>

                <div>
                    <label class="block text-sm font-medium text-gray-700 mb-1">Payment status</label>
                    <select name="payment_status" style="width:100%;" class="border-gray-300 rounded-md text-sm">
                        @foreach (['pending', 'paid', 'failed'] as $status)
                            <option value="{{ $status }}" {{ $order->payment_status === $status ? 'selected' : '' }}>{{ ucfirst($status) }}</option>
                        @endforeach
                    </select>
                </div>

                <button type="submit" style="display:block; width:100%; background-color:#4f46e5; color:#ffffff; padding:10px; border-radius:6px; font-weight:600; border:none; cursor:pointer;">
                    Update order
                </button>
            </form>
        </div>

        <a href="{{ route('admin.orders.index') }}" style="display:inline-block; margin-top:1.5rem; font-size:14px; color:#6b7280;">&larr; Back to orders</a>
    </div>
</x-app-layout>
