<x-app-layout>
    <x-slot name="header">
        <h2 class="font-semibold text-xl text-gray-800 leading-tight">My Favorites</h2>
    </x-slot>

    <div class="py-8 max-w-4xl mx-auto sm:px-6 lg:px-8">
        @if (session('status'))
            <div class="mb-4 rounded-md bg-green-50 p-3 text-sm text-green-700">{{ session('status') }}</div>
        @endif

        <div class="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-4">
            @forelse ($favorites as $favorite)
                @php $item = $favorite->itemable; @endphp
                @if ($item)
                    <div class="bg-white shadow-sm rounded-lg p-4">
                        <p class="font-medium text-gray-800">{{ $item->name }}</p>
                        <p class="mt-2 text-sm">{{ number_format($item->price, 2) }} EGP</p>

                        <form action="{{ route('favorites.toggle') }}" method="POST" class="mt-3">
                            @csrf
                            <input type="hidden" name="type" value="{{ $favorite->itemable_type === \App\Models\Beverage::class ? 'beverage' : 'food' }}">
                            <input type="hidden" name="id" value="{{ $item->id }}">
                            <button type="submit" style="background:none; border:none; color:#dc2626; font-size:13px; cursor:pointer; padding:0;">
                                Remove from favorites
                            </button>
                        </form>
                    </div>
                @endif
            @empty
                <p class="text-sm text-gray-400 col-span-full">You haven't favorited anything yet.</p>
            @endforelse
        </div>

        <a href="{{ route('menu.index') }}" style="display:inline-block; margin-top:1.5rem; font-size:14px; color:#6b7280;">&larr; Back to menu</a>
    </div>
</x-app-layout>
