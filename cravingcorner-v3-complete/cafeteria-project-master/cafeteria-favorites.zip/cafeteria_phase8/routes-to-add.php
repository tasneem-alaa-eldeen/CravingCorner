<?php
// Add to routes/web.php, inside the customer auth group (with menu/cart/orders):

use App\Http\Controllers\Customer\FavoriteController;

Route::middleware('auth')->group(function () {
    Route::get('/favorites', [FavoriteController::class, 'index'])->name('favorites.index');
    Route::post('/favorites/toggle', [FavoriteController::class, 'toggle'])->name('favorites.toggle');
});
