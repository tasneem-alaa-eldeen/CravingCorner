<?php
// Add inside the SAME admin group in routes/web.php
// (Route::middleware(['auth','admin'])->prefix('admin')->name('admin.')->group(...)):

use App\Http\Controllers\Admin\UserController as AdminUserController;

Route::resource('users', AdminUserController::class)->only(['index', 'show', 'update', 'destroy']);
