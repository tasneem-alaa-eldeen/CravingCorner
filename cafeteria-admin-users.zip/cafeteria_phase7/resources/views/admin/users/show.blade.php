<x-app-layout>
    <x-slot name="header">
        <h2 class="font-semibold text-xl text-gray-800 leading-tight">{{ $user->name }}</h2>
    </x-slot>

    <div class="py-8 max-w-2xl mx-auto sm:px-6 lg:px-8">
        @if (session('status'))
            <div class="mb-4 rounded-md bg-green-50 p-3 text-sm text-green-700">{{ session('status') }}</div>
        @endif

        <div class="bg-white shadow-sm rounded-lg p-6 mb-6">
            <dl class="space-y-2 text-sm">
                <div class="flex justify-between"><dt class="text-gray-500">Email</dt><dd>{{ $user->email }}</dd></div>
                <div class="flex justify-between"><dt class="text-gray-500">Phone</dt><dd>{{ $user->phone ?? '—' }}</dd></div>
                <div class="flex justify-between"><dt class="text-gray-500">Age</dt><dd>{{ $user->age ?? '—' }}</dd></div>
                <div class="flex justify-between"><dt class="text-gray-500">Joined</dt><dd>{{ $user->created_at->format('Y-m-d') }}</dd></div>
            </dl>

            <form action="{{ route('admin.users.update', $user) }}" method="POST" class="mt-4 flex items-center gap-3">
                @csrf
                @method('PUT')
                <label class="text-sm text-gray-500">Role</label>
                <select name="role" style="width:auto;" class="border-gray-300 rounded-md text-sm">
                    <option value="customer" {{ $user->role === 'customer' ? 'selected' : '' }}>Customer</option>
                    <option value="admin" {{ $user->role === 'admin' ? 'selected' : '' }}>Admin</option>
                </select>
                <button type="submit" style="background-color:#4f46e5; color:#ffffff; padding:6px 14px; border-radius:6px; font-size:13px; font-weight:600; border:none; cursor:pointer;">
                    Save
                </button>
            </form>
        </div>

        <div class="bg-white shadow-sm rounded-lg overflow-hidden">
            <div class="px-5 py-3 border-b font-semibold text-gray-700">Order history</div>
            @forelse ($user->orders as $order)
                <div class="flex items-center justify-between px-5 py-3 border-b last:border-0 text-sm">
                    <span>#{{ $order->id }} — {{ $order->created_at->format('Y-m-d') }}</span>
                    <span class="capitalize">{{ $order->status }} — {{ number_format($order->total_price, 2) }} EGP</span>
                </div>
            @empty
                <p class="px-5 py-6 text-sm text-gray-400">No orders yet.</p>
            @endforelse
        </div>

        <a href="{{ route('admin.users.index') }}" style="display:inline-block; margin-top:1.5rem; font-size:14px; color:#6b7280;">&larr; Back to users</a>
    </div>
</x-app-layout>
